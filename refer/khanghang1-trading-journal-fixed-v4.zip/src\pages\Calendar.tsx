
import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '../context.tsx';
import { Card } from '../components/ui/Card.tsx';
import { AnalyticsService } from '../services/analyticsService.ts';
import { cn, formatCurrency } from '../lib/utils.ts';

function sameDay(left: Date, right: Date) {
  return left.getFullYear() === right.getFullYear() && left.getMonth() === right.getMonth() && left.getDate() === right.getDate();
}

function dateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export default function Calendar() {
  const { trades } = useApp();
  const dailyPnL = useMemo(() => AnalyticsService.getDailyPnL(trades), [trades]);
  const latestDate = dailyPnL.at(-1)?.date || new Date();
  const [viewDate, setViewDate] = useState(new Date(latestDate.getFullYear(), latestDate.getMonth(), 1));
  const [selectedKey, setSelectedKey] = useState(dateKey(latestDate));

  const dailyMap = useMemo(() => Object.fromEntries(dailyPnL.map((item) => [item.key, item])), [dailyPnL]);
  const monthDays = useMemo(() => {
    const first = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1);
    const start = new Date(first);
    const mondayIndex = (first.getDay() + 6) % 7;
    start.setDate(first.getDate() - mondayIndex);
    return Array.from({ length: 42 }, (_, index) => {
      const date = new Date(start);
      date.setDate(start.getDate() + index);
      return date;
    });
  }, [viewDate]);

  const monthItems = dailyPnL.filter((item) => item.date.getFullYear() === viewDate.getFullYear() && item.date.getMonth() === viewDate.getMonth());
  const monthPnl = monthItems.reduce((sum, item) => sum + item.pnl, 0);
  const winDays = monthItems.filter((item) => item.pnl > 0).length;
  const lossDays = monthItems.filter((item) => item.pnl < 0).length;
  const bestDay = monthItems.reduce<typeof monthItems[number] | undefined>((best, item) => (!best || item.pnl > best.pnl ? item : best), undefined);
  const worstDay = monthItems.reduce<typeof monthItems[number] | undefined>((worst, item) => (!worst || item.pnl < worst.pnl ? item : worst), undefined);
  const selectedDay = dailyMap[selectedKey];
  const selectedTrades = trades.filter((trade) => {
    const date = AnalyticsService.parseTradeDate(trade);
    return date && dateKey(date) === selectedKey;
  });
  const maxAbs = Math.max(...monthItems.map((item) => Math.abs(item.pnl)), 1);

  const moveMonth = (offset: number) => {
    setViewDate((current) => new Date(current.getFullYear(), current.getMonth() + offset, 1));
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1fr_360px]">
        <Card title="Lịch PnL tháng" extra={<div className="flex items-center gap-2"><button onClick={() => moveMonth(-1)} className="rounded-lg p-2 text-gray-500 hover:bg-foreground/5 hover:text-foreground"><ChevronLeft size={18} /></button><span className="min-w-32 text-center text-sm font-bold text-foreground">Thắng {viewDate.getMonth() + 1}/{viewDate.getFullYear()}</span><button onClick={() => moveMonth(1)} className="rounded-lg p-2 text-gray-500 hover:bg-foreground/5 hover:text-foreground"><ChevronRight size={18} /></button></div>}>
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold uppercase tracking-widest text-gray-500">
            {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((day) => <div key={day}>{day}</div>)}
          </div>
          <div className="mt-4 grid grid-cols-7 gap-2">
            {monthDays.map((date) => {
              const key = dateKey(date);
              const item = dailyMap[key];
              const isCurrentMonth = date.getMonth() === viewDate.getMonth();
              const isSelected = key === selectedKey;
              const intensity = item ? Math.max(0.14, Math.abs(item.pnl) / maxAbs) : 0;
              const bg = item ? item.pnl >= 0 ? `rgba(16,185,129,${intensity})` : `rgba(244,63,94,${intensity})` : undefined;
              return (
                <button key={key} onClick={() => setSelectedKey(key)} className={cn('min-h-28 rounded-2xl border p-3 text-left transition-all hover:border-blue-500/60', isSelected ? 'border-blue-500 ring-1 ring-blue-500/60' : 'border-foreground/8', !isCurrentMonth && 'opacity-25')} style={{ background: bg }}>
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-bold text-gray-400">{date.getDate()}</span>
                    {item && <span className="rounded-full bg-black/20 px-2 py-0.5 text-[10px] font-bold text-white">{item.trades}</span>}
                  </div>
                  {item && <div className="mt-4"><div className={cn('font-mono text-sm font-bold', item.pnl >= 0 ? 'text-emerald-100' : 'text-rose-100')}>{item.pnl >= 0 ? '+' : ''}{formatCurrency(item.pnl)}</div><div className="mt-1 text-[10px] uppercase tracking-widest text-white/65">{item.wins} th?ng ? {item.losses} thua</div></div>}
                </button>
              );
            })}
          </div>
        </Card>

        <div className="space-y-6">
          <Card title="Thắng k? th?ng">
            <div className="space-y-4 text-sm">
              <div className="flex items-center justify-between"><span className="text-gray-500">T?ng PnL th?ng</span><span className={cn('font-mono font-bold', monthPnl >= 0 ? 'text-emerald-500' : 'text-rose-500')}>{monthPnl >= 0 ? '+' : ''}{formatCurrency(monthPnl)}</span></div>
              <div className="flex items-center justify-between"><span className="text-gray-500">Ng?y th?ng</span><span className="font-bold text-emerald-500">{winDays} ng?y</span></div>
              <div className="flex items-center justify-between"><span className="text-gray-500">Ng?y thua</span><span className="font-bold text-rose-500">{lossDays} ng?y</span></div>
              <div className="flex items-center justify-between"><span className="text-gray-500">Ng?y t?t nh?t</span><span className="font-mono font-bold text-emerald-500">{bestDay ? `${bestDay.label} ? ${formatCurrency(bestDay.pnl)}` : '?'}</span></div>
              <div className="flex items-center justify-between"><span className="text-gray-500">Ng?y x?u nh?t</span><span className="font-mono font-bold text-rose-500">{worstDay ? `${worstDay.label} ? ${formatCurrency(worstDay.pnl)}` : '?'}</span></div>
            </div>
          </Card>

          <Card title="Ngày đang chọn" subtitle={selectedDay ? `${selectedDay.trades} giao dịch` : 'Không có giao dịch'}>
            {selectedDay ? <div className="space-y-3"><div className={cn('text-3xl font-mono font-black', selectedDay.pnl >= 0 ? 'text-emerald-500' : 'text-rose-500')}>{selectedDay.pnl >= 0 ? '+' : ''}{formatCurrency(selectedDay.pnl)}</div>{selectedTrades.map((trade) => <div key={trade.rowNumber} className="flex items-center justify-between rounded-xl bg-foreground/5 p-3 text-xs"><div><div className="font-bold text-foreground">{trade.symbol}</div><div className="text-gray-500">{trade.strategy || trade.sector || 'Không ghi chú'}</div></div><div className={cn('font-mono font-bold', trade.netPnL >= 0 ? 'text-emerald-500' : 'text-rose-500')}>{trade.netPnL >= 0 ? '+' : ''}{formatCurrency(trade.netPnL)}</div></div>)}</div> : <p className="text-sm text-gray-500">Chọn ngày có màu trên lịch để xem chi tiết.</p>}
          </Card>
        </div>
      </div>
    </div>
  );
}
