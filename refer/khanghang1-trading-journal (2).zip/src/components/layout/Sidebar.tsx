import { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Square, 
  Circle, 
  Triangle, 
  Pentagon, 
  Hexagon, 
  Settings, 
  ChevronLeft, 
  ChevronRight,
  Sun,
  Moon,
  Monitor
} from 'lucide-react';
import { cn } from '../../lib/utils.ts';
import { useApp } from '../../context.tsx';

const navItems = [
  { path: '/overview', label: 'Tổng quan', icon: Square },
  { path: '/journal', label: 'Nhật ký', icon: Circle },
  { path: '/analytics', label: 'Phân tích', icon: Triangle },
  { path: '/calendar', label: 'Lịch PnL', icon: Pentagon },
  { path: '/risk', label: 'Rủi ro', icon: Hexagon },
  { path: '/settings', label: 'Cài đặt', icon: Settings },
];

export default function Sidebar({ isMobileMenuOpen, setIsMobileMenuOpen }: { isMobileMenuOpen: boolean, setIsMobileMenuOpen: (val: boolean) => void }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { settings, isLoading, theme, setTheme } = useApp();
  const location = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const toggleTheme = () => {
    if (theme === 'system') setTheme('dark');
    else if (theme === 'dark') setTheme('light');
    else setTheme('system');
  };

  const ThemeIcon = theme === 'system' ? Monitor : (theme === 'dark' ? Moon : Sun);
  const themeLabel = theme === 'system' ? 'System Theme' : (theme === 'dark' ? 'Dark Mode' : 'Light Mode');

  return (
    <>
      {/* Mobile backdrop */}
      <div 
        className={cn(
          "fixed inset-0 bg-black/50 z-40 transition-opacity md:hidden",
          isMobileMenuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
        onClick={() => setIsMobileMenuOpen(false)}
      />
      <motion.aside
        initial={false}
        animate={{ 
          width: isCollapsed ? '72px' : '240px'
        }}
        className={cn(
          "fixed md:relative top-0 left-0 h-full flex flex-col border-r border-white/5 bg-[var(--sidebar-bg)] transition-all duration-300 z-50 overflow-hidden shrink-0",
          isCollapsed ? "items-center" : "items-start",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full",
          "md:translate-x-0"
        )}
      >
      {/* Logo */}
      <div className={cn("p-6 w-full flex items-center", isCollapsed ? "justify-center" : "justify-between")}>
        {!isCollapsed && (
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-foreground flex items-center justify-center font-bold text-background text-sm">
              {settings.appName ? settings.appName.substring(0, 2).toUpperCase() : 'KH'}
            </div>
            <span className="font-bold text-sm tracking-tight">{settings.appName || 'KhangHang1'}</span>
          </div>
        )}
        {isCollapsed && (
          <div className="w-8 h-8 rounded bg-foreground flex items-center justify-center font-bold text-background text-xs">
            {settings.appName ? settings.appName.substring(0, 2).toUpperCase() : 'KH'}
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 w-full px-3 space-y-0.5 mt-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-300 group relative",
              isActive 
                ? "bg-foreground/5 text-foreground font-semibold" 
                : "text-gray-500 hover:text-foreground hover:bg-foreground/[0.03]"
            )}
          >
            {({ isActive }) => (
              <>
                <item.icon size={18} strokeWidth={isActive ? 2.5 : 1.5} />
                {!isCollapsed && <span className="text-[13px] tracking-tight">{item.label}</span>}
                {isCollapsed && (
                  <div className="absolute left-14 px-2 py-1 bg-foreground text-background text-[10px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50 font-bold uppercase">
                    {item.label}
                  </div>
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Footer info */}
      <div className="w-full p-4 space-y-2">
        <button
          onClick={toggleTheme}
          className="w-full flex items-center justify-center gap-3 p-2.5 rounded-xl hover:bg-foreground/5 text-gray-500 hover:text-foreground transition-all"
        >
          <ThemeIcon size={18} />
          {!isCollapsed && <span className="text-[13px] font-medium">{themeLabel}</span>}
        </button>

        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="hidden md:flex w-full items-center justify-center p-2 rounded-xl hover:bg-foreground/5 text-gray-500 transition-all"
        >
          {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>
    </motion.aside>
    </>
  );
}
