import { useState } from 'react';
import { useApp } from '../context.tsx';
import { Card } from '../components/ui/Card.tsx';
import { Database, Link2, ExternalLink, Save, CheckCircle, AlertCircle, Lock, User } from 'lucide-react';
import { cn } from '../lib/utils.ts';

export default function Settings() {
  const { settings, updateSettings, isLoading } = useApp();
  const [localSheetId, setLocalSheetId] = useState(settings.sheetId);
  const [localApiKey, setLocalApiKey] = useState(settings.apiKey);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [authEnabled, setAuthEnabled] = useState(settings.auth?.enabled ?? true);
  const [username, setUsername] = useState(settings.auth?.username || 'admin');
  const [password, setPassword] = useState(settings.auth?.passwordHash || '');
  const [appName, setAppName] = useState(settings.appName || 'KhangHang1');
  const [authSaveSuccess, setAuthSaveSuccess] = useState(false);

  const handleSaveSheet = () => {
    updateSettings({
      sheetId: localSheetId,
      apiKey: localApiKey,
      isDemoMode: false,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleSaveAuth = () => {
    updateSettings({
      appName,
      auth: {
        ...settings.auth,
        enabled: authEnabled,
        username,
        passwordHash: password
      }
    });
    setAuthSaveSuccess(true);
    setTimeout(() => setAuthSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <Card title="Bảo mật & Đăng nhập" subtitle="Cài đặt bảo vệ cho dashboard của bạn.">
        <div className="space-y-6 pt-4">
           {/* Auth mode toggle */}
           <div className="flex items-center justify-between p-4 rounded-xl bg-blue-500/5 border border-blue-500/10 mb-4">
              <div>
                 <h4 className="text-sm font-bold text-gray-200">Mật khẩu bảo vệ</h4>
                 <p className="text-xs text-gray-400">Yêu cầu đăng nhập khi mở dashboard.</p>
              </div>
              <button 
                onClick={() => setAuthEnabled(!authEnabled)}
                className={cn(
                  "w-12 h-6 rounded-full transition-colors relative",
                  authEnabled ? "bg-blue-500" : "bg-gray-700"
                )}
              >
                <div className={cn(
                  "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                  authEnabled ? "left-7" : "left-1"
                )} />
              </button>
           </div>

           {authEnabled && (
             <div className="space-y-4">
                <div className="space-y-1.5">
                   <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                      <User size={12} />
                      Tên người dùng
                   </label>
                   <input 
                      type="text" 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="e.g. admin" 
                      className="w-full bg-background border border-foreground/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50"
                   />
                </div>

                <div className="space-y-1.5">
                   <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                      <Lock size={12} />
                      Mật khẩu
                   </label>
                   <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Nhập mật khẩu" 
                      className="w-full bg-background border border-foreground/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50"
                   />
                </div>
             </div>
           )}

           <div className="space-y-4 pt-4 border-t border-foreground/5">
                <div className="space-y-1.5">
                   <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                      Tên tài khoản / Ứng dụng
                   </label>
                   <input 
                      type="text" 
                      value={appName}
                      onChange={(e) => setAppName(e.target.value)}
                      placeholder="e.g. KhangHang1" 
                      className="w-full bg-background border border-foreground/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50"
                   />
                </div>
           </div>

           <div className="pt-4">
              <button 
                onClick={handleSaveAuth}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-600/20"
              >
                {authSaveSuccess ? <CheckCircle size={18} /> : <Save size={18} />}
                {authSaveSuccess ? 'Đã lưu cấu hình bảo mật!' : 'Lưu bảo mật'}
              </button>
           </div>
        </div>
      </Card>

      <Card title="Kết nối Google Sheets" subtitle="Cấu hình nguồn dữ liệu cho nhật ký giao dịch của bạn.">
        <div className="space-y-6 pt-4">
           {/* Demo mode toggle */}
           <div className="flex items-center justify-between p-4 rounded-xl bg-blue-500/5 border border-blue-500/10">
              <div>
                 <h4 className="text-sm font-bold text-gray-200">Chế độ Demo</h4>
                 <p className="text-xs text-gray-400">Dùng dữ liệu mẫu để trải nghiệm dashboard.</p>
              </div>
              <button 
                onClick={() => updateSettings({ isDemoMode: !settings.isDemoMode })}
                className={cn(
                  "w-12 h-6 rounded-full transition-colors relative",
                  settings.isDemoMode ? "bg-blue-500" : "bg-gray-700"
                )}
              >
                <div className={cn(
                  "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                  settings.isDemoMode ? "left-7" : "left-1"
                )} />
              </button>
           </div>

           <div className="space-y-4">
              <div className="space-y-1.5">
                 <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                    <Database size={12} />
                    Google Sheet ID
                 </label>
                 <input 
                    type="text" 
                    value={localSheetId}
                    onChange={(e) => setLocalSheetId(e.target.value)}
                    placeholder="e.g. 1aBC...xyz" 
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50"
                 />
              </div>

              <div className="space-y-1.5">
                 <label className="text-xs font-bold text-gray-500 uppercase flex items-center gap-2">
                    <Link2 size={12} />
                    API Key
                 </label>
                 <input 
                    type="password" 
                    value={localApiKey}
                    onChange={(e) => setLocalApiKey(e.target.value)}
                    placeholder="Nhập Google API Key của bạn" 
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50"
                 />
              </div>
           </div>

           <div className="pt-4 flex items-center gap-4">
              <button 
                onClick={handleSaveSheet}
                disabled={isLoading}
                className="flex-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-600/20"
              >
                {saveSuccess ? <CheckCircle size={18} /> : <Save size={18} />}
                {saveSuccess ? 'Đã lưu!' : 'Lưu kết nối'}
              </button>
              
              <a 
                href="https://console.cloud.google.com/apis/credentials" 
                target="_blank" 
                rel="noreferrer"
                className="p-3 rounded-xl border border-white/10 hover:bg-white/5 text-gray-400 transition-all"
                title="Lấy API Key"
              >
                <ExternalLink size={20} />
              </a>
           </div>

           <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/10 flex gap-4">
              <AlertCircle size={20} className="text-amber-500 shrink-0" />
              <div className="text-[11px] text-gray-400 leading-relaxed">
                 <p className="font-bold text-amber-500 mb-1">Lưu ý về bảo mật:</p>
                 API Key và Sheet ID chỉ được lưu cục bộ trên trình duyệt của bạn (LocalStorage). 
                 Đảm bảo Sheet của bạn có quyền read access cho API Key này, và tab dữ liệu phải được đặt tên chính xác là <code className="text-gray-200">JOURNAL</code>.
              </div>
           </div>
        </div>
      </Card>

      <Card title="Hướng dẫn cấu hình">
         <div className="space-y-4 text-sm text-gray-400 leading-relaxed">
            <p>1. Truy cập Google Sheet Nhật ký của bạn.</p>
            <p>2. Copy phần ID từ URL: <code className="text-blue-400">docs.google.com/spreadsheets/d/<b>[SHEET_ID]</b>/edit</code></p>
            <p>3. Tạo API Key tại Google Cloud Console (bật Google Sheets API).</p>
            <p>4. Đảm bảo sheet có tab tên <code className="text-gray-200">JOURNAL</code> với các cột chuẩn từ KhangHang1.</p>
         </div>
      </Card>
    </div>
  );
}
