import { useApp } from '../context.tsx';
import { Card } from '../components/ui/Card.tsx';
import { cn, formatCurrency } from '../lib/utils.ts';
import { eachDayOfInterval, startOfMonth, endOfMonth, isSameDay, format, startOfWeek, endOfWeek } from 'date-fns';
import { vi } from 'date-fns/locale';

export default function Calendar() {
  const { trades } = useApp();
  const now = new Date();
  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(now)),
    end: endOfWeek(endOfMonth(now))
  });

  const getDayPnL = (day: Date) => {
    return trades
      .filter(t => t.closeDate && isSameDay(new Date(t.closeDate), day))
      .reduce((sum, t) => sum + t.netPnL, 0);
  };

  const weekdays = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card title="Lịch PnL Tháng" className="lg:col-span-2">
          <div className="grid grid-cols-7 gap-2">
            {weekdays.map(d => (
              <div key={d} className="text-center text-[10px] font-bold text-gray-500 uppercase py-2">
                {d}
              </div>
            ))}
            {days.map(day => {
              const pnl = getDayPnL(day);
              const isCurrentMonth = day.getMonth() === now.getMonth();
              const isToday = isSameDay(day, now);

              return (
                <div 
                  key={day.toISOString()} 
                  className={cn(
                    "min-h-[80px] p-2 rounded-xl flex flex-col justify-between border transition-all",
                    isCurrentMonth ? "bg-foreground/[0.02] border-foreground/5" : "bg-transparent border-transparent opacity-20",
                    isToday && "ring-1 ring-blue-500 bg-blue-500/5 items-center justify-center p-0"
                  )}
                >
                  <span className={cn(
                    "text-[10px] font-bold",
                    isToday ? "bg-blue-500 text-white px-1.5 py-0.5 rounded-full" : "text-gray-500"
                  )}>
                    {format(day, 'd')}
                  </span>
                  {pnl !== 0 && (
                    <div className={cn(
                      "text-[9px] font-mono font-bold text-center py-1 rounded",
                      pnl > 0 ? "bg-emerald-500/10 text-emerald-500" : "bg-rose-500/10 text-rose-500"
                    )}>
                      {pnl > 0 ? "+" : ""}{(pnl / 1000).toFixed(0)}k
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        <div className="space-y-6">
          <Card title="Thống kê tháng">
             <div className="space-y-4 pt-2">
                <div className="flex justify-between items-center text-sm">
                   <span className="text-gray-500">Tổng PnL tháng:</span>
                   <span className="font-bold font-mono text-emerald-500">+1.2M</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                   <span className="text-gray-500">Ngày thắng:</span>
                   <span className="font-bold text-emerald-500">12 ngày</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                   <span className="text-gray-500">Ngày thua:</span>
                   <span className="font-bold text-rose-500">4 ngày</span>
                </div>
             </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
