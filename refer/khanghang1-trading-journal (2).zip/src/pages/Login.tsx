import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useApp } from '../context.tsx';
import { Lock, LogIn, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils.ts';

export default function Login() {
  const { authState, login, settings, updateSettings } = useApp();
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [remember, setRemember] = useState(settings.auth?.rememberMe || false);

  if (authState.isAuthenticated) {
    return <Navigate to="/overview" replace />;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (remember !== settings.auth.rememberMe) {
        updateSettings({ auth: { ...settings.auth, rememberMe: remember } });
    }
    const success = login(password);
    if (!success) {
      setError(true);
      setPassword('');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-background border border-foreground/5 rounded-2xl p-8 shadow-2xl">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center mb-4 border border-blue-500/20">
            <Lock className="w-8 h-8 text-blue-500" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">{settings.appName || 'KhangHang1'} Journal</h1>
          <p className="text-gray-500 text-sm mt-2">Vui lòng đăng nhập để tiếp tục</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-2">Mật khẩu</label>
            <input
              type="password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(false); }}
              placeholder="Nhập mật khẩu..."
              className={cn(
                "w-full bg-foreground/5 border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all",
                error ? "border-rose-500/50" : "border-foreground/10"
              )}
              autoFocus
            />
            {error && (
              <div className="flex items-center gap-2 mt-2 text-rose-500 text-sm">
                <AlertCircle className="w-4 h-4" />
                <span>Mật khẩu không chính xác</span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
             <label className="flex items-center gap-2 cursor-pointer">
               <input 
                 type="checkbox" 
                 checked={remember} 
                 onChange={(e) => setRemember(e.target.checked)}
                 className="rounded bg-background border-foreground/10 text-blue-500 focus:ring-blue-500"
               />
               <span className="text-sm text-gray-500">Ghi nhớ đăng nhập</span>
             </label>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <LogIn className="w-5 h-5" />
            Đăng nhập
          </button>
        </form>
      </div>
      
      <div className="mt-8 text-[11px] text-gray-600 tracking-widest uppercase font-medium">
        Powered by dahodo.com
      </div>
    </div>
  );
}
