import { useState } from 'react';
import { useApp } from '../context.tsx';
import { Card } from '../components/ui/Card.tsx';
import { AnalyticsService } from '../services/analyticsService.ts';
import { formatCurrency } from '../lib/utils.ts';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

export default function Analytics() {
  const { trades } = useApp();
  const [activeTab, setActiveTab] = useState('strategy');

  const pnlByStrategy = AnalyticsService.getPnLByStrategy(trades);
  const pnlByMood = AnalyticsService.getPnLByMood(trades);
  const pnlBySector = AnalyticsService.getPnLBySector(trades);

  const getActiveData = (): any[] => {
    if (activeTab === 'strategy') return pnlByStrategy;
    if (activeTab === 'sector') return pnlBySector;
    return pnlByMood;
  };

  const getLabelKey = () => {
    if (activeTab === 'strategy') return 'strategy';
    if (activeTab === 'sector') return 'sector';
    return 'mood';
  };

  const getTitle = () => {
    if (activeTab === 'strategy') return 'Chiến lược';
    if (activeTab === 'sector') return 'Nhóm ngành';
    return 'Tâm lý';
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-foreground/5 rounded-xl w-fit">
        <button 
           onClick={() => setActiveTab('strategy')}
           className={cn(
             "px-4 py-2 rounded-lg text-sm font-medium transition-all",
             activeTab === 'strategy' ? "bg-blue-600 text-white" : "text-gray-500 hover:text-foreground"
           )}
        >
           Chiến lược
        </button>
        <button 
           onClick={() => setActiveTab('sector')}
           className={cn(
             "px-4 py-2 rounded-lg text-sm font-medium transition-all",
             activeTab === 'sector' ? "bg-blue-600 text-white" : "text-gray-500 hover:text-foreground"
           )}
        >
           Nhóm ngành
        </button>
        <button 
           onClick={() => setActiveTab('mood')}
           className={cn(
             "px-4 py-2 rounded-lg text-sm font-medium transition-all",
             activeTab === 'mood' ? "bg-blue-600 text-white" : "text-gray-500 hover:text-foreground"
           )}
        >
           Tâm lý
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title={`PnL theo ${getTitle()}`}>
          <div className="h-[400px] w-full mt-4">
             <ResponsiveContainer width="100%" height="100%">
                <BarChart 
                   layout="vertical" 
                   data={getActiveData()}
                   margin={{ left: 40 }}
                >
                   <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="rgba(255,255,255,0.05)" />
                   <XAxis type="number" hide />
                   <YAxis 
                      type="category" 
                      dataKey={getLabelKey()} 
                      stroke="#9CA3AF" 
                      fontSize={12} 
                      width={100}
                      axisLine={false}
                      tickLine={false}
                   />
                   <Tooltip 
                      cursor={{ fill: 'rgba(255,255,255,0.05)' }} 
                      contentStyle={{ backgroundColor: '#111827', border: 'none', borderRadius: '8px' }}
                      formatter={(value: number) => formatCurrency(value)}
                   />
                   <Bar dataKey="pnl">
                      {getActiveData().map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? '#10B981' : '#EF4444'} />
                      ))}
                   </Bar>
                </BarChart>
             </ResponsiveContainer>
          </div>
        </Card>

        <div className="space-y-6">
           <Card title="Phân tích chi tiết">
              <div className="space-y-4">
                 {getActiveData().map((item: any, i: number) => (
                   <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-foreground/5 border border-foreground/5">
                      <div className="flex flex-col">
                         <span className="text-sm font-bold text-foreground">{item[getLabelKey()]}</span>
                         <span className="text-[10px] text-gray-500 uppercase font-bold">{item.trades || 0} Giao dịch</span>
                      </div>
                      <div className={cn("text-sm font-mono font-bold", item.pnl >= 0 ? "text-emerald-500" : "text-rose-500")}>
                        {formatCurrency(item.pnl)}
                      </div>
                   </div>
                 ))}
              </div>
           </Card>
        </div>
      </div>
    </div>
  );
}

// Support functions used inside the component needs `cn`
import { cn } from '../lib/utils.ts';
