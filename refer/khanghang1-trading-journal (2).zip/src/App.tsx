import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AppProvider, useApp } from './context.tsx';
import Sidebar from './components/layout/Sidebar.tsx';
import Topbar from './components/layout/Topbar.tsx';
import Overview from './pages/Overview.tsx';
import Journal from './pages/Journal.tsx';
import Analytics from './pages/Analytics.tsx';
import Calendar from './pages/Calendar.tsx';
import Risk from './pages/Risk.tsx';
import Settings from './pages/Settings.tsx';
import Login from './pages/Login.tsx';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { authState } = useApp();
  const location = useLocation();

  if (!authState.isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}

function MainLayout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans selection:bg-blue-500/30 transition-colors duration-300">
      <Sidebar isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        <main className="flex-1 p-3 sm:p-4 md:p-8 overflow-y-auto">
          <Routes>
            <Route path="/overview" element={<Overview />} />
            <Route path="/journal" element={<Journal />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/risk" element={<Risk />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/" element={<Navigate to="/overview" replace />} />
          </Routes>
        </main>
        <footer className="py-6 px-4 md:px-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 font-medium gap-4">
           <div className="flex items-center gap-4">
              <span>© 2024 KhangHang1 Journal</span>
              <div className="hidden sm:block w-1 h-1 rounded-full bg-gray-700" />
              <span className="hidden sm:inline">Real-time Trading Insights</span>
           </div>
           <a href="https://dahodo.com" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 transition-colors tracking-widest uppercase text-center">
              Powered by dahodo.com
           </a>
        </footer>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/*" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AppProvider>
  );
}

