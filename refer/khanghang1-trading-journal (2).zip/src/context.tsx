import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { Trade, TradingStats, DashboardSettings, AuthState, AuthSettings } from './types.ts';
import { AnalyticsService } from './services/analyticsService.ts';
import { GoogleSheetsService } from './services/googleSheetsService.ts';
import { DEMO_TRADES } from './constants.ts';

export type ThemeMode = 'light' | 'dark' | 'system';

interface AppContextType {
  trades: Trade[];
  stats: TradingStats | null;
  settings: DashboardSettings;
  isLoading: boolean;
  error: string | null;
  updateSettings: (newSettings: Partial<DashboardSettings>) => void;
  refreshData: () => Promise<void>;
  
  // Auth
  authState: AuthState;
  login: (password: string) => boolean;
  logout: () => void;
  
  // Theme
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
}

const defaultAuthSettings: AuthSettings = {
  enabled: true,
  username: "admin",
  passwordHash: "admin123", // Simple plain text for local, or hashed. Let's just use plain text here since backend is absent.
  rememberMe: false
};

const defaultSettings: DashboardSettings = {
  sheetId: '',
  apiKey: '',
  isDemoMode: true,
  auth: defaultAuthSettings,
  appName: 'KhangHang1'
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<DashboardSettings>(() => {
    const saved = localStorage.getItem('kh1_settings');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Merge with default auth settings if not present
      if (!parsed.auth) parsed.auth = defaultAuthSettings;
      return parsed;
    }
    return defaultSettings;
  });

  const [trades, setTrades] = useState<Trade[]>([]);
  const [stats, setStats] = useState<TradingStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Theme state
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    return (localStorage.getItem('kh1_theme') as ThemeMode) || 'system';
  });

  // Auth state
  const [authState, setAuthState] = useState<AuthState>(() => {
    if (!settings.auth.enabled) return { isAuthenticated: true, username: 'Guest' };
    
    // Check session or local storage depending on what user chose
    const localAuth = localStorage.getItem('kh1_auth');
    if (localAuth === 'true') return { isAuthenticated: true, username: settings.auth.username };
    
    const sessionAuth = sessionStorage.getItem('kh1_auth');
    if (sessionAuth === 'true') return { isAuthenticated: true, username: settings.auth.username };

    return { isAuthenticated: false, username: null };
  });

  const setTheme = (mode: ThemeMode) => {
    setThemeState(mode);
    localStorage.setItem('kh1_theme', mode);
  };

  useEffect(() => {
    const applyTheme = () => {
      let isDark = theme === 'dark';
      if (theme === 'system') {
        isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      }
      document.documentElement.classList.toggle('dark', isDark);
    };

    applyTheme();

    if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme();
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, [theme]);

  const login = (password: string) => {
    // Very simple check
    if (password === settings.auth.passwordHash) {
      setAuthState({ isAuthenticated: true, username: settings.auth.username });
      if (settings.auth.rememberMe) {
        localStorage.setItem('kh1_auth', 'true');
      } else {
        sessionStorage.setItem('kh1_auth', 'true');
      }
      return true;
    }
    return false;
  };

  const logout = () => {
    setAuthState({ isAuthenticated: false, username: null });
    localStorage.removeItem('kh1_auth');
    sessionStorage.removeItem('kh1_auth');
  };

  const updateSettings = (newSettings: Partial<DashboardSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    localStorage.setItem('kh1_settings', JSON.stringify(updated));
    
    // Auto-update auth state if login is disabled
    if (newSettings.auth && !newSettings.auth.enabled && !authState.isAuthenticated) {
      setAuthState({ isAuthenticated: true, username: 'Guest' });
    } else if (newSettings.auth && newSettings.auth.enabled && !localStorage.getItem('kh1_auth') && !sessionStorage.getItem('kh1_auth')) {
      // Re-evaluate if we enable it
      setAuthState({ isAuthenticated: false, username: null });
    }
  };

  const refreshData = async () => {
    if (settings.isDemoMode) {
      setTrades(DEMO_TRADES);
      setStats(AnalyticsService.calculateStats(DEMO_TRADES));
      return;
    }

    if (!settings.sheetId || !settings.apiKey) {
      setError('Vui lòng cấu hình Google Sheets trong phần Cài đặt.');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const data = await GoogleSheetsService.fetchTrades(settings.sheetId, settings.apiKey);
      setTrades(data);
      setStats(AnalyticsService.calculateStats(data));
    } catch (err) {
      setError('Không thể lấy dữ liệu từ Google Sheets. Vui lòng kiểm tra cấu hình.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (authState.isAuthenticated) {
      refreshData();
    }
  }, [settings.sheetId, settings.apiKey, settings.isDemoMode, authState.isAuthenticated]);

  return (
    <AppContext.Provider value={{ trades, stats, settings, isLoading, error, updateSettings, refreshData, authState, login, logout, theme, setTheme }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
