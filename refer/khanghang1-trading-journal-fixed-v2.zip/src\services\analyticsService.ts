﻿import type { Trade, TradingStats } from '../types.ts';

export class AnalyticsService {
  static calculateStats(trades: Trade[]): TradingStats {
    const closedTrades = trades.filter((trade) => trade.status !== 'Đang mở');
    const winningTrades = closedTrades.filter((trade) => trade.status === 'Thắng');
    const losingTrades = closedTrades.filter((trade) => trade.status === 'Thua');
    const breakEvenTrades = closedTrades.filter((trade) => trade.status === 'Hòa');
    const openTrades = trades.filter((trade) => trade.status === 'Đang mở');

    const totalTrades = closedTrades.length;
    const winRate = totalTrades > 0 ? winningTrades.length / totalTrades : 0;

    const grossProfit = winningTrades.reduce((sum, trade) => sum + trade.netPnL, 0);
    const grossLoss = Math.abs(losingTrades.reduce((sum, trade) => sum + trade.netPnL, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;

    const netPnL = trades.reduce((sum, trade) => sum + trade.netPnL, 0);
    const currentBalance = trades.length > 0 ? trades[trades.length - 1].equity : 0;

    let maxDrawdown = 0;
    let peak = 0;

    trades.forEach((trade) => {
      const balance = trade.equity;
      if (balance > peak) peak = balance;
      const drawdown = peak > 0 ? (peak - balance) / peak : 0;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    });

    return {
      netPnL,
      currentBalance,
      totalTrades,
      winRate,
      profitFactor,
      maxDrawdown,
      expectancy: totalTrades > 0 ? netPnL / totalTrades : 0,
      avgRR: 0,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      breakEvenTrades: breakEvenTrades.length,
      openTrades: openTrades.length,
    };
  }

  static getEquityCurve(trades: Trade[]) {
    return trades.map((trade, index) => ({
      name: index + 1,
      date: trade.closeDate || trade.openDate,
      balance: trade.equity,
    }));
  }

  static getPnLByStrategy(trades: Trade[]) {
    const strategyMap: Record<string, { strategy: string; pnl: number; trades: number }> = {};
    trades.forEach((trade) => {
      const strategy = trade.strategy || 'Không tên';
      if (!strategyMap[strategy]) {
        strategyMap[strategy] = { strategy, pnl: 0, trades: 0 };
      }
      strategyMap[strategy].pnl += trade.netPnL;
      strategyMap[strategy].trades += 1;
    });
    return Object.values(strategyMap).sort((left, right) => right.pnl - left.pnl);
  }

  static getPnLByMood(trades: Trade[]) {
    const moodMap: Record<string, { mood: string; pnl: number; trades: number }> = {};
    trades.forEach((trade) => {
      const mood = trade.mood || 'Không ghi chú';
      if (!moodMap[mood]) {
        moodMap[mood] = { mood, pnl: 0, trades: 0 };
      }
      moodMap[mood].pnl += trade.netPnL;
      moodMap[mood].trades += 1;
    });
    return Object.values(moodMap).sort((left, right) => right.pnl - left.pnl);
  }

  static getPnLBySector(trades: Trade[]) {
    const sectorMap: Record<string, { sector: string; pnl: number; trades: number }> = {};
    trades.forEach((trade) => {
      const sector = trade.sector || 'Chưa phân loại';
      if (!sectorMap[sector]) {
        sectorMap[sector] = { sector, pnl: 0, trades: 0 };
      }
      sectorMap[sector].pnl += trade.netPnL;
      sectorMap[sector].trades += 1;
    });
    return Object.values(sectorMap).sort((left, right) => right.pnl - left.pnl);
  }
}
