import { useApp } from '../context.tsx';
import { Card } from '../components/ui/Card.tsx';
import { formatCurrency, formatPercent } from '../lib/utils.ts';
import { AlertCircle, TrendingDown, ShieldCheck, ZapOff } from 'lucide-react';

export default function Risk() {
  const { stats, trades } = useApp();

  const maxLoss = Math.min(...trades.map(t => t.netPnL), 0);
  const avgLoss = trades.filter(t => t.netPnL < 0).reduce((sum, t, _, arr) => sum + t.netPnL / arr.length, 0);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="border-rose-500/20 bg-rose-500/[0.02]">
          <div className="flex items-center gap-3 mb-4">
             <div className="p-2 rounded-lg bg-rose-500/10 text-rose-500">
                <TrendingDown size={20} />
             </div>
             <h3 className="font-bold text-foreground">Max Drawdown</h3>
          </div>
          <div className="text-3xl font-mono font-bold text-rose-500">{formatPercent(stats?.maxDrawdown || 0)}</div>
          <p className="text-xs text-gray-500 mt-2">Mức sụt giảm tài khoản lớn nhất từ trước đến nay.</p>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
             <div className="p-2 rounded-lg bg-blue-500/10 text-blue-500">
                <ShieldCheck size={20} />
             </div>
             <h3 className="font-bold text-foreground">Rủi ro trung bình</h3>
          </div>
          <div className="text-3xl font-mono font-bold text-foreground">{formatCurrency(Math.abs(avgLoss))}</div>
          <p className="text-xs text-gray-500 mt-2">Mức thua lỗ trung bình trên mỗi lệnh thua.</p>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
             <div className="p-2 rounded-lg bg-amber-500/10 text-amber-500">
                <ZapOff size={20} />
             </div>
             <h3 className="font-bold text-foreground">Thua lỗ lớn nhất</h3>
          </div>
          <div className="text-3xl font-mono font-bold text-foreground">{formatCurrency(Math.abs(maxLoss))}</div>
          <p className="text-xs text-gray-500 mt-2">Lệnh có mức lỗ ròng cao nhất trong nhật ký.</p>
        </Card>
      </div>

      <Card title="Cảnh báo rủi ro & Kỷ luật">
        <div className="space-y-4">
           {stats && stats.maxDrawdown > 0.05 && (
             <div className="flex gap-4 p-4 rounded-xl bg-rose-500/10 border border-rose-500/20">
                <AlertCircle className="text-rose-500 shrink-0" />
                <div>
                   <h4 className="text-sm font-bold text-rose-400">Drawdown vượt ngưỡng cảnh báo!</h4>
                   <p className="text-xs text-gray-400 mt-1">Tài khoản của bạn đã sụt giảm hơn 5%. Hãy xem xét giảm quy mô vị thế và rà soát lại chiến lược.</p>
                </div>
             </div>
           )}

           <div className="flex gap-4 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <ShieldCheck className="text-blue-500 shrink-0" />
              <div>
                 <h4 className="text-sm font-bold text-blue-400">Kỷ luật giao dịch tốt</h4>
                 <p className="text-xs text-gray-400 mt-1">Không có lệnh nào vi phạm mức cắt lỗ quá mức quy định. Bạn đang kiểm soát rủi ro khá ổn định.</p>
              </div>
           </div>
        </div>
      </Card>
    </div>
  );
}
