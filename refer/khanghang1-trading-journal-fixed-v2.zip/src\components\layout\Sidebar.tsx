﻿import { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight, Circle, Hexagon, Monitor, Moon, Pentagon, Settings, Square, Sun, Triangle } from 'lucide-react';
import { cn } from '../../lib/utils.ts';
import { useApp } from '../../context.tsx';

const navItems = [
  { path: '/overview', label: 'Tổng quan', icon: Square },
  { path: '/journal', label: 'Nhật ký', icon: Circle },
  { path: '/analytics', label: 'Phân tích', icon: Triangle },
  { path: '/calendar', label: 'Lịch PnL', icon: Pentagon },
  { path: '/risk', label: 'Rủi ro', icon: Hexagon },
  { path: '/settings', label: 'Cài đặt', icon: Settings },
];

export default function Sidebar({ isMobileMenuOpen, setIsMobileMenuOpen }: { isMobileMenuOpen: boolean; setIsMobileMenuOpen: (val: boolean) => void }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { settings, theme, setTheme } = useApp();
  const location = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname, setIsMobileMenuOpen]);

  const cycleTheme = () => {
    if (theme === 'system') setTheme('dark');
    else if (theme === 'dark') setTheme('light');
    else setTheme('system');
  };

  const ThemeIcon = theme === 'system' ? Monitor : theme === 'dark' ? Moon : Sun;
  const themeLabel = theme === 'system' ? 'System' : theme === 'dark' ? 'Dark' : 'Light';

  return (
    <>
      <div className={cn('fixed inset-0 z-40 bg-black/50 transition-opacity md:hidden', isMobileMenuOpen ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0')} onClick={() => setIsMobileMenuOpen(false)} />
      <motion.aside
        initial={false}
        animate={{ width: isCollapsed ? '72px' : '240px' }}
        className={cn('fixed left-0 top-0 z-50 flex h-full shrink-0 -translate-x-full flex-col overflow-hidden border-r border-white/5 bg-[var(--sidebar-bg)] transition-all duration-300 md:relative md:translate-x-0', isCollapsed ? 'items-center' : 'items-start', isMobileMenuOpen && 'translate-x-0')}
      >
        <div className={cn('flex w-full items-center p-6', isCollapsed ? 'justify-center' : 'justify-between')}>
          {!isCollapsed ? (
            <div className="flex items-center gap-2.5">
              <div className="flex h-7 w-7 items-center justify-center rounded bg-foreground text-sm font-bold text-background">{settings.appName ? settings.appName.substring(0, 2).toUpperCase() : 'KH'}</div>
              <span className="text-sm font-bold tracking-tight">{settings.appName || 'KhangHang1'}</span>
            </div>
          ) : (
            <div className="flex h-8 w-8 items-center justify-center rounded bg-foreground text-xs font-bold text-background">{settings.appName ? settings.appName.substring(0, 2).toUpperCase() : 'KH'}</div>
          )}
        </div>

        <nav className="mt-2 w-full flex-1 space-y-0.5 px-3">
          {navItems.map((item) => (
            <NavLink key={item.path} to={item.path} className={({ isActive }) => cn('group relative flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all duration-300', isActive ? 'bg-foreground/5 font-semibold text-foreground' : 'text-gray-500 hover:bg-foreground/[0.03] hover:text-foreground')}>
              {({ isActive }) => (
                <>
                  <item.icon size={18} strokeWidth={isActive ? 2.5 : 1.5} />
                  {!isCollapsed && <span className="text-[13px] tracking-tight">{item.label}</span>}
                  {isCollapsed && <div className="pointer-events-none absolute left-14 z-50 rounded bg-foreground px-2 py-1 text-[10px] font-bold uppercase whitespace-nowrap text-background opacity-0 transition-opacity group-hover:opacity-100">{item.label}</div>}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="w-full space-y-2 p-4">
          <button onClick={cycleTheme} className="flex w-full items-center justify-center gap-3 rounded-xl p-2.5 text-gray-500 transition-all hover:bg-foreground/5 hover:text-foreground">
            <ThemeIcon size={18} />
            {!isCollapsed && <span className="text-[13px] font-medium">{themeLabel}</span>}
          </button>
          <button onClick={() => setIsCollapsed(!isCollapsed)} className="hidden w-full items-center justify-center rounded-xl p-2 text-gray-500 transition-all hover:bg-foreground/5 md:flex">
            {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>
      </motion.aside>
    </>
  );
}
