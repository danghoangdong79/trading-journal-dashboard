import { TrendingUp, TrendingDown, Minus, Clock } from 'lucide-react';
import type { TradeStatus, PositionType, Trade } from './types.ts';

export const STATUS_CONFIG: Record<TradeStatus, { label: string; color: string; icon: any }> = {
  'Thắng': { label: 'Thắng', color: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20', icon: TrendingUp },
  'Thua': { label: 'Thua', color: 'bg-rose-500/10 text-rose-500 border-rose-500/20', icon: TrendingDown },
  'Hòa': { label: 'Hòa', color: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: Minus },
  'Đang mở': { label: 'Đang mở', color: 'bg-blue-500/10 text-blue-500 border-blue-500/20', icon: Clock },
};

export const POSITION_CONFIG: Record<PositionType, { label: string; color: string }> = {
  'LONG': { label: 'LARGE', color: 'bg-emerald-500/10 text-emerald-500' },
  'SHORT': { label: 'SHORT', color: 'bg-rose-500/10 text-rose-500' },
};

export const DEMO_TRADES: Trade[] = [
  {
    rowNumber: 2,
    status: 'Thắng',
    account: 'VNDIRECT-01',
    assetType: 'Phái sinh',
    symbol: 'VN30F2405',
    position: 'LONG',
    orderType: 'LIMIT',
    strategy: 'Breakout',
    openDate: '2024-05-01',
    openTime: '09:30',
    closeDate: '2024-05-01',
    closeTime: '10:45',
    holdingDays: 0,
    volume: 5,
    entryPrice: 1250.5,
    exitPrice: 1255.2,
    stopLoss: 1248,
    takeProfit: 1260,
    amplitude: 4.7,
    grossPnL: 2350000,
    feesAndTaxes: 25000,
    netPnL: 2325000,
    mood: 'Tự tin',
    reviewNote: 'Lệnh tốt, tuân thủ kỷ luật',
    sector: 'VN30',
    entryDateTime: new Date('2024-05-01 09:30'),
    exitDateTime: new Date('2024-05-01 10:45'),
    equity: 102325000
  },
  {
    rowNumber: 3,
    status: 'Thua',
    account: 'VNDIRECT-01',
    assetType: 'Cổ phiếu',
    symbol: 'FPT',
    position: 'LONG',
    orderType: 'MARKET',
    strategy: 'Pullback',
    openDate: '2024-05-02',
    openTime: '13:15',
    closeDate: '2024-05-02',
    closeTime: '14:30',
    holdingDays: 0,
    volume: 1000,
    entryPrice: 115.2,
    exitPrice: 113.8,
    stopLoss: 114,
    takeProfit: 120,
    amplitude: -1.4,
    grossPnL: -1400000,
    feesAndTaxes: 15000,
    netPnL: -1415000,
    mood: 'Nôn nóng',
    reviewNote: 'Vào lệnh hơi sớm',
    sector: 'Công nghệ',
    entryDateTime: new Date('2024-05-02 13:15'),
    exitDateTime: new Date('2024-05-02 14:30'),
    equity: 100910000
  }
];
