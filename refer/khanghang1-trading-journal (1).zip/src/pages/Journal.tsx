import { useState } from 'react';
import { useApp } from '../context.tsx';
import { Card } from '../components/ui/Card.tsx';
import { cn, formatCurrency } from '../lib/utils.ts';
import { Search, Filter, ArrowUpDown, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { STATUS_CONFIG, POSITION_CONFIG } from '../constants.ts';

export default function Journal() {
  const { trades, isLoading } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAsset, setFilterAsset] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');

  const filteredTrades = trades.filter(t => {
    const matchesSearch = t.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         t.strategy.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAsset = filterAsset === 'All' || t.assetType === filterAsset;
    const matchesStatus = filterStatus === 'All' || t.status === filterStatus;
    return matchesSearch && matchesAsset && matchesStatus;
  }).reverse();

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Toolbar */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
            <input 
              type="text" 
              placeholder="Tìm mã hoặc chiến lược..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/5 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50"
            />
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
            <select 
               value={filterAsset}
               onChange={(e) => setFilterAsset(e.target.value)}
               className="bg-[#111827] border border-white/10 rounded-xl text-xs px-3 py-2 focus:outline-none"
            >
               <option value="All">Tất cả tài sản</option>
               <option value="Phái sinh">Phái sinh</option>
               <option value="Cổ phiếu">Cổ phiếu</option>
            </select>
            <select 
               value={filterStatus}
               onChange={(e) => setFilterStatus(e.target.value)}
               className="bg-[#111827] border border-white/10 rounded-xl text-xs px-3 py-2 focus:outline-none"
            >
               <option value="All">Tất cả trạng thái</option>
               <option value="Thắng">Thắng</option>
               <option value="Thua">Thua</option>
               <option value="Hòa">Hòa</option>
               <option value="Đang mở">Đang mở</option>
            </select>
            <button 
              onClick={() => {setSearchTerm(''); setFilterAsset('All'); setFilterStatus('All');}}
              className="p-2 rounded-xl border border-white/10 hover:bg-white/5 text-gray-400"
              title="Xóa bộ lọc"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      </Card>

      {/* Table */}
      <Card className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-white/[0.02] border-b border-white/5 text-[10px] text-gray-500 uppercase tracking-widest font-bold">
              <tr>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Mã / Tài sản</th>
                <th className="px-6 py-4 text-center">Giá Vào / Đóng</th>
                <th className="px-6 py-4 text-center">Khối lượng</th>
                <th className="px-6 py-4 text-right">Lãi/Lỗ Ròng</th>
                <th className="px-6 py-4 text-center">Chiến lược</th>
                <th className="px-6 py-4 text-center">Ngày mở</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={7} className="px-6 py-6"><div className="h-4 bg-white/5 rounded w-full" /></td>
                  </tr>
                ))
              ) : filteredTrades.length > 0 ? (
                filteredTrades.map((trade) => {
                  const statusInfo = STATUS_CONFIG[trade.status];

                  return (
                    <tr key={trade.rowNumber} className="group hover:bg-white/5 transition-colors cursor-pointer">
                      <td className="px-6 py-4">
                        <div className={cn(
                          "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold border",
                          statusInfo?.color || "bg-gray-500/10 text-gray-500 border-gray-500/20"
                        )}>
                          {statusInfo?.icon && <statusInfo.icon size={10} />}
                          {trade.status}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="font-bold text-gray-100">{trade.symbol}</span>
                          <span className="text-[10px] text-gray-500 uppercase font-medium">{trade.assetType} • {trade.position}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                         <div className="flex items-center justify-center gap-2">
                            <span className="text-xs font-mono text-gray-400">{trade.entryPrice.toLocaleString()}</span>
                            <span className="text-gray-700">→</span>
                            <span className="text-xs font-mono text-gray-200">{trade.exitPrice > 0 ? trade.exitPrice.toLocaleString() : "---"}</span>
                         </div>
                      </td>
                      <td className="px-6 py-4 text-center font-mono text-xs text-gray-300">
                        {trade.volume.toLocaleString()}
                      </td>
                      <td className={cn(
                        "px-6 py-4 text-right font-mono text-xs font-bold",
                        trade.netPnL >= 0 ? "text-emerald-500" : "text-rose-500"
                      )}>
                        {trade.netPnL >= 0 ? "+" : ""}{formatCurrency(trade.netPnL)}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-xs text-gray-400 bg-white/5 px-2 py-1 rounded-lg">
                          {trade.strategy}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center font-mono text-[10px] text-gray-500">
                        {trade.openDate} {trade.openTime}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                    <p className="text-lg mb-1">Chưa có giao dịch phù hợp</p>
                    <p className="text-xs">Hãy thử thay đổi từ khóa tìm kiếm hoặc bộ lọc.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
