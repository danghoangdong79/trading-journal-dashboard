import { Search, RefreshCw, Download, Calendar as CalendarIcon, Wallet } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { useApp } from '../../context.tsx';
import { formatCurrency } from '../../lib/utils.ts';

const BREADCRUMBS: Record<string, string> = {
  '/overview': 'Tổng quan',
  '/journal': 'Nhật ký giao dịch',
  '/analytics': 'Phân tích hiệu suất',
  '/calendar': 'Lịch PnL',
  '/risk': 'Quản trị rủi ro',
  '/settings': 'Cài đặt kết nối',
};

export default function Topbar() {
  const location = useLocation();
  const { stats, refreshData, isLoading, settings } = useApp();

  return (
    <header className="h-14 border-b border-white/5 bg-background/50 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-30 transition-colors duration-300">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5 text-[11px] font-bold uppercase tracking-widest text-gray-500">
          <span>Journal</span>
          <div className="w-1 h-1 rounded-full bg-gray-700" />
          <span className="text-foreground">{BREADCRUMBS[location.pathname] || 'Dashboard'}</span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        {/* Balance preview */}
        {!isLoading && stats && (
          <div className="hidden md:flex items-center gap-6">
             <div className="flex flex-col items-end">
                <span className="text-[9px] text-gray-500 uppercase font-black tracking-tighter">Current Balance</span>
                <span className="text-[13px] font-mono font-bold text-foreground leading-none">{formatCurrency(stats.currentBalance)}</span>
             </div>
             <div className="h-4 w-px bg-white/10" />
             <div className="flex flex-col items-end">
                <span className="text-[9px] text-gray-500 uppercase font-black tracking-tighter">Account PnL</span>
                <span className={`text-[13px] font-mono font-bold leading-none ${stats.netPnL >= 0 ? "text-emerald-500" : "text-rose-500"}`}>
                  {stats.netPnL >= 0 ? "+" : ""}{formatCurrency(stats.netPnL)}
                </span>
             </div>
          </div>
        )}

        {/* Global actions */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => refreshData()}
            disabled={isLoading}
            className="p-2 rounded-lg hover:bg-foreground/5 text-gray-500 hover:text-foreground transition-all disabled:opacity-50"
          >
            <RefreshCw size={16} className={isLoading ? "animate-spin" : ""} />
          </button>
          
          <button className="p-2 rounded-lg hover:bg-foreground/5 text-gray-500 hover:text-foreground transition-all">
            <Download size={16} />
          </button>
        </div>
        
        {settings.isDemoMode && (
          <div className="px-2 py-0.5 rounded-full bg-amber-500 text-[9px] font-black uppercase text-white tracking-widest shadow-lg shadow-amber-500/20">
            Demo
          </div>
        )}
      </div>
    </header>
  );
}
