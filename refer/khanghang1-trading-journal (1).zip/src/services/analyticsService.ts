import type { Trade, TradingStats } from '../types.ts';

export class AnalyticsService {
  static calculateStats(trades: Trade[]): TradingStats {
    const closedTrades = trades.filter(t => t.status !== 'Đang mở');
    const winningTrades = closedTrades.filter(t => t.status === 'Thắng');
    const losingTrades = closedTrades.filter(t => t.status === 'Thua');
    const breakEvenTrades = closedTrades.filter(t => t.status === 'Hòa');
    const openTrades = trades.filter(t => t.status === 'Đang mở');

    const totalTrades = closedTrades.length;
    const winRate = totalTrades > 0 ? winningTrades.length / totalTrades : 0;
    
    const grossProfit = winningTrades.reduce((sum, t) => sum + t.netPnL, 0);
    const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + t.netPnL, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : (grossProfit > 0 ? Infinity : 0);
    
    const netPnL = trades.reduce((sum, t) => sum + t.netPnL, 0);
    const currentBalance = trades.length > 0 ? trades[trades.length - 1].equity : 0;

    // Simplified Max Drawdown calculation
    let maxDD = 0;
    let peak = 0;
    
    trades.forEach(t => {
      const balance = t.equity;
      if (balance > peak) peak = balance;
      const dd = peak > 0 ? (peak - balance) / peak : 0;
      if (dd > maxDD) maxDD = dd;
    });

    const expectancy = totalTrades > 0 ? netPnL / totalTrades : 0;
    // We don't have expectedRR directly in the new schema, but we can set it to 0 or calculate if needed
    const avgRR = 0;

    return {
      netPnL,
      currentBalance,
      totalTrades,
      winRate,
      profitFactor,
      maxDrawdown: maxDD,
      expectancy,
      avgRR,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      breakEvenTrades: breakEvenTrades.length,
      openTrades: openTrades.length
    };
  }

  static getEquityCurve(trades: Trade[]) {
    return trades.map((t, i) => ({
      name: i + 1,
      date: t.closeDate || t.openDate,
      balance: t.equity
    }));
  }

  static getPnLByStrategy(trades: Trade[]) {
    const strategyMap: Record<string, { strategy: string; pnl: number; trades: number }> = {};
    trades.forEach(t => {
      const strategy = t.strategy || 'Không tên';
      if (!strategyMap[strategy]) {
        strategyMap[strategy] = { strategy, pnl: 0, trades: 0 };
      }
      strategyMap[strategy].pnl += t.netPnL;
      strategyMap[strategy].trades += 1;
    });
    return Object.values(strategyMap).sort((a, b) => b.pnl - a.pnl);
  }

  static getPnLByMood(trades: Trade[]) {
    const moodMap: Record<string, { mood: string; pnl: number; trades: number }> = {};
    trades.forEach(t => {
      const mood = t.mood || 'Không ghi chú';
      if (!moodMap[mood]) {
        moodMap[mood] = { mood, pnl: 0, trades: 0 };
      }
      moodMap[mood].pnl += t.netPnL;
      moodMap[mood].trades += 1;
    });
    return Object.values(moodMap).sort((a, b) => b.pnl - a.pnl);
  }

  static getPnLBySector(trades: Trade[]) {
    const sectorMap: Record<string, { sector: string; pnl: number; trades: number }> = {};
    trades.forEach(t => {
      const sector = t.sector || 'Chưa phân loại';
      if (!sectorMap[sector]) {
        sectorMap[sector] = { sector, pnl: 0, trades: 0 };
      }
      sectorMap[sector].pnl += t.netPnL;
      sectorMap[sector].trades += 1;
    });
    return Object.values(sectorMap).sort((a, b) => b.pnl - a.pnl);
  }
}
