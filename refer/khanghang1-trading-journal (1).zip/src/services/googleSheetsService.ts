import type { Trade, TradeStatus, AssetType, PositionType } from '../types.ts';

export class GoogleSheetsService {
  static async fetchTrades(sheetId: string, apiKey: string): Promise<Trade[]> {
    if (!sheetId || !apiKey) {
      throw new Error('Sheet ID and API Key are required');
    }

    const range = 'JOURNAL!A1:X2000';
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${apiKey}`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (!data.values || data.values.length < 2) {
        return [];
      }

      const rows = data.values.slice(1);
      let runningEquity = 0;

      return rows.map((row: any[], i: number) => {
        const netPnL = parseFloat(String(row[20] || '0').replace(/[,.]/g, '')) || 0;
        runningEquity += netPnL;

        const openDate = row[7] || '';
        const openTime = row[8] || '';
        const closeDate = row[9] || '';
        const closeTime = row[10] || '';

        const parseDateTime = (dateStr: string, timeStr: string) => {
          if (!dateStr) return null;
          try {
            // Simplified parsing, assuming YYYY-MM-DD or DD/MM/YYYY
            // For a production app, we'd use date-fns or similar
            return new Date(`${dateStr} ${timeStr}`);
          } catch (e) {
            return null;
          }
        };

        return {
          rowNumber: i + 2,
          status: (row[0] || 'Đang mở') as TradeStatus,
          account: row[1] || '',
          assetType: (row[2] || 'Cổ phiếu') as AssetType,
          symbol: row[3] || '',
          position: (row[4] || 'LONG') as PositionType,
          orderType: row[5] || '',
          strategy: row[6] || '',
          openDate,
          openTime,
          closeDate,
          closeTime,
          holdingDays: parseFloat(row[11]) || 0,
          volume: parseFloat(row[12]) || 0,
          entryPrice: parseFloat(String(row[13] || '0').replace(/[,.]/g, '')) || 0,
          exitPrice: parseFloat(String(row[14] || '0').replace(/[,.]/g, '')) || 0,
          stopLoss: parseFloat(String(row[15] || '0').replace(/[,.]/g, '')) || 0,
          takeProfit: parseFloat(String(row[16] || '0').replace(/[,.]/g, '')) || 0,
          amplitude: parseFloat(row[17]) || 0,
          grossPnL: parseFloat(String(row[18] || '0').replace(/[,.]/g, '')) || 0,
          feesAndTaxes: parseFloat(String(row[19] || '0').replace(/[,.]/g, '')) || 0,
          netPnL,
          mood: row[21] || '',
          reviewNote: row[22] || '',
          sector: row[23] || '',
          entryDateTime: parseDateTime(openDate, openTime),
          exitDateTime: parseDateTime(closeDate, closeTime),
          equity: runningEquity,
        };
      });
    } catch (error) {
      console.error('Error fetching Google Sheets data:', error);
      throw error;
    }
  }
}
