import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { Trade, TradingStats, DashboardSettings } from './types.ts';
import { AnalyticsService } from './services/analyticsService.ts';
import { GoogleSheetsService } from './services/googleSheetsService.ts';
import { DEMO_TRADES } from './constants.ts';

interface AppContextType {
  trades: Trade[];
  stats: TradingStats | null;
  settings: DashboardSettings;
  isLoading: boolean;
  error: string | null;
  updateSettings: (newSettings: Partial<DashboardSettings>) => void;
  refreshData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<DashboardSettings>(() => {
    const saved = localStorage.getItem('kh1_settings');
    return saved ? JSON.parse(saved) : { sheetId: '', apiKey: '', isDemoMode: true };
  });

  const [trades, setTrades] = useState<Trade[]>([]);
  const [stats, setStats] = useState<TradingStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('kh1_theme') as 'light' | 'dark') || 'dark';
  });

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('kh1_theme', newTheme);
  };

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const updateSettings = (newSettings: Partial<DashboardSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    localStorage.setItem('kh1_settings', JSON.stringify(updated));
  };

  const refreshData = async () => {
    if (settings.isDemoMode) {
      setTrades(DEMO_TRADES);
      setStats(AnalyticsService.calculateStats(DEMO_TRADES));
      return;
    }

    if (!settings.sheetId || !settings.apiKey) {
      setError('Vui lòng cấu hình Google Sheets trong phần Cài đặt.');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const data = await GoogleSheetsService.fetchTrades(settings.sheetId, settings.apiKey);
      setTrades(data);
      setStats(AnalyticsService.calculateStats(data));
    } catch (err) {
      setError('Không thể lấy dữ liệu từ Google Sheets. Vui lòng kiểm tra cấu hình.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, [settings.sheetId, settings.apiKey, settings.isDemoMode]);

  return (
    <AppContext.Provider value={{ trades, stats, settings, isLoading, error, updateSettings, refreshData }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
