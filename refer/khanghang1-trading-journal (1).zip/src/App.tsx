import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context.tsx';
import Sidebar from './components/layout/Sidebar.tsx';
import Topbar from './components/layout/Topbar.tsx';
import Overview from './pages/Overview.tsx';
import Journal from './pages/Journal.tsx';
import Analytics from './pages/Analytics.tsx';
import Calendar from './pages/Calendar.tsx';
import Risk from './pages/Risk.tsx';
import Settings from './pages/Settings.tsx';

export default function App() {
  return (
    <AppProvider>
      <Router>
        <div className="flex min-h-screen bg-background text-foreground font-sans selection:bg-blue-500/30 transition-colors duration-300">
          <Sidebar />
          <div className="flex-1 flex flex-col min-w-0">
            <Topbar />
            <main className="flex-1 p-4 md:p-8 overflow-y-auto">
              <Routes>
                <Route path="/overview" element={<Overview />} />
                <Route path="/journal" element={<Journal />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/calendar" element={<Calendar />} />
                <Route path="/risk" element={<Risk />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/" element={<Navigate to="/overview" replace />} />
              </Routes>
            </main>
            <footer className="py-6 px-8 border-t border-white/5 flex items-center justify-between text-[11px] text-gray-500 font-medium">
               <div className="flex items-center gap-4">
                  <span>© 2024 KhangHang1 Journal</span>
                  <div className="w-1 h-1 rounded-full bg-gray-700" />
                  <span>Real-time Trading Insights</span>
               </div>
               <a href="https://dahodo.com" target="_blank" className="hover:text-blue-500 transition-colors tracking-widest uppercase">
                  Powered by dahodo.com
               </a>
            </footer>
          </div>
        </div>
      </Router>
    </AppProvider>
  );
}
