export type TradeStatus = '✅ Win' | '❌ Lose' | '➖ Hòa' | '⏳ Đang mở';
export type AssetType = 'Phái sinh' | 'Cổ phiếu';
export type PositionType = 'Long' | 'Short' | 'Mua' | 'Bán';
export type TradingSession = 'ATO' | 'Sáng' | 'Chiều' | 'ATC';
export type TradingMood = string;

export interface Trade {
  stt: number;
  status: TradeStatus;
  assetType: AssetType;
  symbol: string;
  strategy: string;
  position: PositionType;
  session: TradingSession;
  entryTime: string;
  exitTime: string;
  duration: string;
  balance: number;
  volume: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  exitPrice: number;
  actualPoints: number;
  expectedRR: number;
  grossPnL: number;
  fee: number;
  tax: number;
  netPnL: number;
  closedBalance: number;
  mood: TradingMood;
  notes: string;
}

export interface TradingStats {
  netPnL: number;
  currentBalance: number;
  totalTrades: number;
  winRate: number;
  profitFactor: number;
  maxDrawdown: number;
  expectancy: number;
  avgRR: number;
  winningTrades: number;
  losingTrades: number;
  breakEvenTrades: number;
  openTrades: number;
}

export interface DashboardSettings {
  sheetId: string;
  apiKey: string;
  isDemoMode: boolean;
}
