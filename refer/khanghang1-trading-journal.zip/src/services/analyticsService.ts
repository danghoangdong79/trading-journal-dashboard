import type { Trade, TradingStats } from '../types.ts';

export class AnalyticsService {
  static calculateStats(trades: Trade[]): TradingStats {
    const closedTrades = trades.filter(t => t.status !== '⏳ Đang mở');
    const winningTrades = closedTrades.filter(t => t.status === '✅ Win');
    const losingTrades = closedTrades.filter(t => t.status === '❌ Lose');
    const breakEvenTrades = closedTrades.filter(t => t.status === '➖ Hòa');
    const openTrades = trades.filter(t => t.status === '⏳ Đang mở');

    const totalTrades = closedTrades.length;
    const winRate = totalTrades > 0 ? winningTrades.length / totalTrades : 0;
    
    const grossProfit = winningTrades.reduce((sum, t) => sum + t.netPnL, 0);
    const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + t.netPnL, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : (grossProfit > 0 ? Infinity : 0);
    
    const netPnL = trades.reduce((sum, t) => sum + t.netPnL, 0);
    const currentBalance = trades.length > 0 ? trades[trades.length - 1].closedBalance || trades[trades.length - 1].balance : 0;

    // Simplified Max Drawdown calculation
    let maxBalance = 0;
    let maxDD = 0;
    let runningBalance = currentBalance;
    
    // We would ideally iterate through trades chronologically to find peak and valley
    // For now, let's assume trades are sorted by date
    let peak = 0;
    trades.forEach(t => {
      const balance = t.closedBalance || t.balance;
      if (balance > peak) peak = balance;
      const dd = peak > 0 ? (peak - balance) / peak : 0;
      if (dd > maxDD) maxDD = dd;
    });

    const expectancy = totalTrades > 0 ? netPnL / totalTrades : 0;
    const avgRR = totalTrades > 0 ? trades.reduce((sum, t) => sum + (t.expectedRR || 0), 0) / totalTrades : 0;

    return {
      netPnL,
      currentBalance,
      totalTrades,
      winRate,
      profitFactor,
      maxDrawdown: maxDD,
      expectancy,
      avgRR,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      breakEvenTrades: breakEvenTrades.length,
      openTrades: openTrades.length
    };
  }

  static getEquityCurve(trades: Trade[]) {
    let balance = 0;
    return trades.map((t, i) => {
      balance = t.closedBalance || t.balance;
      return {
        name: i + 1,
        date: t.exitTime || t.entryTime,
        balance: balance
      };
    });
  }

  static getPnLByStrategy(trades: Trade[]) {
    const strategyMap: Record<string, { strategy: string; pnl: number; trades: number }> = {};
    trades.forEach(t => {
      if (!strategyMap[t.strategy]) {
        strategyMap[t.strategy] = { strategy: t.strategy, pnl: 0, trades: 0 };
      }
      strategyMap[t.strategy].pnl += t.netPnL;
      strategyMap[t.strategy].trades += 1;
    });
    return Object.values(strategyMap).sort((a, b) => b.pnl - a.pnl);
  }

  static getPnLByMood(trades: Trade[]) {
    const moodMap: Record<string, { mood: string; pnl: number }> = {};
    trades.forEach(t => {
      const mood = t.mood || 'Không ghi chú';
      if (!moodMap[mood]) {
        moodMap[mood] = { mood, pnl: 0 };
      }
      moodMap[mood].pnl += t.netPnL;
    });
    return Object.values(moodMap).sort((a, b) => b.pnl - a.pnl);
  }
}
