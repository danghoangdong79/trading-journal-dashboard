import type { Trade } from '../types.ts';

export class GoogleSheetsService {
  static async fetchTrades(sheetId: string, apiKey: string): Promise<Trade[]> {
    if (!sheetId || !apiKey) {
      throw new Error('Sheet ID and API Key are required');
    }

    const range = 'JOURNAL!A1:AH2000';
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${apiKey}`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (!data.values || data.values.length < 2) {
        return [];
      }

      const headers = data.values[0];
      const rows = data.values.slice(1);

      // Map headers to indices
      const getIdx = (name: string) => headers.indexOf(name);

      return rows.map((row: any[], i: number) => ({
        stt: parseInt(row[getIdx('STT')]) || i + 1,
        status: row[getIdx('Trạng Thái')] || '⏳ Đang mở',
        assetType: row[getIdx('Loại TS')],
        symbol: row[getIdx('Mã GD')],
        strategy: row[getIdx('Chiến Lược')],
        position: row[getIdx('Vị Thế')],
        session: row[getIdx('Phiên')],
        entryTime: row[getIdx('Ngày & Giờ Vào')],
        exitTime: row[getIdx('Ngày & Giờ Đóng')],
        duration: row[getIdx('TG Giao Dịch')],
        balance: parseFloat(row[getIdx('Số Dư')]) || 0,
        volume: parseFloat(row[getIdx('Số HĐ/CP')]) || 0,
        entryPrice: parseFloat(row[getIdx('Giá Vào')]) || 0,
        stopLoss: parseFloat(row[getIdx('Cắt Lỗ (SL)')]) || 0,
        takeProfit: parseFloat(row[getIdx('Chốt Lời (TP)')]) || 0,
        exitPrice: parseFloat(row[getIdx('Giá Đóng')]) || 0,
        actualPoints: parseFloat(row[getIdx('Điểm Thực Tế')]) || 0,
        expectedRR: parseFloat(row[getIdx('R:R Kỳ Vọng')]) || 0,
        grossPnL: parseFloat(row[getIdx('Lãi/Lỗ Gộp')]) || 0,
        fee: parseFloat(row[getIdx('Phí GD')]) || 0,
        tax: parseFloat(row[getIdx('Thuế')]) || 0,
        netPnL: parseFloat(row[getIdx('Lãi/Lỗ Ròng')]) || 0,
        closedBalance: parseFloat(row[getIdx('Số Dư Đã Đóng')]) || 0,
        mood: row[getIdx('Tâm Lý')],
        notes: row[getIdx('Ghi Chú')],
      }));
    } catch (error) {
      console.error('Error fetching Google Sheets data:', error);
      throw error;
    }
  }
}
