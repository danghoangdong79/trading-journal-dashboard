import { Trash2, TrendingUp, TrendingDown, Minus, Clock } from 'lucide-react';
import type { TradeStatus, PositionType } from './types.ts';

export const STATUS_CONFIG: Record<TradeStatus, { label: string; color: string; icon: any }> = {
  '✅ Win': { label: 'Thắng', color: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20', icon: TrendingUp },
  '❌ Lose': { label: 'Thua', color: 'bg-rose-500/10 text-rose-500 border-rose-500/20', icon: TrendingDown },
  '➖ Hòa': { label: 'Hòa', color: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: Minus },
  '⏳ Đang mở': { label: 'Đang mở', color: 'bg-blue-500/10 text-blue-500 border-blue-500/20', icon: Clock },
};

export const POSITION_CONFIG: Record<PositionType, { label: string; color: string }> = {
  'Long': { label: 'Long', color: 'bg-blue-500/10 text-blue-500' },
  'Short': { label: 'Short', color: 'bg-orange-500/10 text-orange-500' },
  'Mua': { label: 'Mua', color: 'bg-emerald-500/10 text-emerald-500' },
  'Bán': { label: 'Bán', color: 'bg-rose-500/10 text-rose-500' },
};

export const DEMO_TRADES: any[] = [
  {
    stt: 1,
    status: '✅ Win',
    assetType: 'Phái sinh',
    symbol: 'VN30F2405',
    strategy: 'Breakout',
    position: 'Long',
    session: 'Sáng',
    entryTime: '2024-05-01 09:30',
    exitTime: '2024-05-01 10:45',
    volume: 5,
    entryPrice: 1250.5,
    exitPrice: 1255.2,
    netPnL: 2350000,
    balance: 102350000,
    closedBalance: 102350000,
    mood: 'Tự tin'
  },
  {
    stt: 2,
    status: '❌ Lose',
    assetType: 'Cổ phiếu',
    symbol: 'FPT',
    strategy: 'Pullback',
    position: 'Mua',
    session: 'Chiều',
    entryTime: '2024-05-02 13:15',
    exitTime: '2024-05-02 14:30',
    volume: 1000,
    entryPrice: 115.2,
    exitPrice: 113.8,
    netPnL: -1400000,
    balance: 100950000,
    closedBalance: 100950000,
    mood: 'Nôn nóng'
  },
  {
    stt: 3,
    status: '✅ Win',
    assetType: 'Phái sinh',
    symbol: 'VN30F2405',
    strategy: 'Trend Follow',
    position: 'Short',
    session: 'Chiều',
    entryTime: '2024-05-03 14:00',
    exitTime: '2024-05-03 14:45',
    volume: 3,
    entryPrice: 1260.1,
    exitPrice: 1252.3,
    netPnL: 2340000,
    balance: 103290000,
    closedBalance: 103290000,
    mood: 'Tự tin'
  },
  {
    stt: 4,
    status: '✅ Win',
    assetType: 'Cổ phiếu',
    symbol: 'MWG',
    strategy: 'Breakout',
    position: 'Mua',
    session: 'Sáng',
    entryTime: '2024-05-04 10:00',
    exitTime: '2024-05-04 11:30',
    volume: 2000,
    entryPrice: 58.5,
    exitPrice: 61.2,
    netPnL: 5400000,
    balance: 108690000,
    closedBalance: 108690000,
    mood: 'Tự tin'
  },
  {
    stt: 5,
    status: '❌ Lose',
    assetType: 'Phái sinh',
    symbol: 'VN30F2406',
    strategy: 'Scalping',
    position: 'Long',
    session: 'ATC',
    entryTime: '2024-05-05 14:15',
    exitTime: '2024-05-05 14:45',
    volume: 10,
    entryPrice: 1270.5,
    exitPrice: 1268.2,
    netPnL: -2300000,
    balance: 106390000,
    closedBalance: 106390000,
    mood: 'Nôn nóng'
  }
];
