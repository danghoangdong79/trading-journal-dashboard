﻿import { useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { Circle, Hexagon, Monitor, Moon, Pentagon, Settings, Square, Sun, Triangle } from 'lucide-react';
import { cn } from '../../lib/utils.ts';
import { useApp } from '../../context.tsx';

const navItems = [
  { path: '/overview', label: 'Tổng quan', icon: Square },
  { path: '/journal', label: 'Nhật ký', icon: Circle },
  { path: '/analytics', label: 'Phân tích', icon: Triangle },
  { path: '/calendar', label: 'Lịch PnL', icon: Pentagon },
  { path: '/risk', label: 'Rủi ro', icon: Hexagon },
  { path: '/settings', label: 'Cài đặt', icon: Settings },
];

export default function Sidebar({ isMobileMenuOpen, setIsMobileMenuOpen }: { isMobileMenuOpen: boolean; setIsMobileMenuOpen: (val: boolean) => void }) {
  const { settings, theme, setTheme } = useApp();
  const location = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname, setIsMobileMenuOpen]);

  const cycleTheme = () => {
    if (theme === 'system') setTheme('dark');
    else if (theme === 'dark') setTheme('light');
    else setTheme('system');
  };

  const ThemeIcon = theme === 'system' ? Monitor : theme === 'dark' ? Moon : Sun;
  const themeLabel = theme === 'system' ? 'System' : theme === 'dark' ? 'Dark' : 'Light';

  return (
    <>
      <div className={cn('fixed inset-0 z-40 bg-black/50 transition-opacity md:hidden', isMobileMenuOpen ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0')} onClick={() => setIsMobileMenuOpen(false)} />
      <motion.aside
        initial={false}
        animate={{ width: 320 }}
        className={cn('fixed left-0 top-0 z-50 flex h-screen w-80 shrink-0 -translate-x-full flex-col overflow-hidden border-r border-white/5 bg-[var(--sidebar-bg)] transition-all duration-300 md:sticky md:translate-x-0', isMobileMenuOpen && 'translate-x-0')}
      >
        <div className="flex w-full items-center p-6">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-foreground text-sm font-bold text-background">PT</div>
            <span className="text-base font-bold tracking-tight">{settings.appName || 'Phương Trần'}</span>
          </div>
        </div>

        <nav className="mt-2 w-full flex-1 space-y-0.5 px-3">
          {navItems.map((item) => (
            <NavLink key={item.path} to={item.path} className={({ isActive }) => cn('group relative flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all duration-300', isActive ? 'bg-foreground/5 font-semibold text-foreground' : 'text-gray-500 hover:bg-foreground/[0.03] hover:text-foreground')}>
              {({ isActive }) => (
                <>
                  <item.icon size={18} strokeWidth={isActive ? 2.5 : 1.5} />
                  <span className="text-[13px] tracking-tight">{item.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="w-full space-y-2 p-4">
          <button onClick={cycleTheme} className="flex w-full items-center justify-center gap-3 rounded-xl p-2.5 text-gray-500 transition-all hover:bg-foreground/5 hover:text-foreground">
            <ThemeIcon size={18} />
            <span className="text-[13px] font-medium">{themeLabel}</span>
          </button>
        </div>
      </motion.aside>
    </>
  );
}
